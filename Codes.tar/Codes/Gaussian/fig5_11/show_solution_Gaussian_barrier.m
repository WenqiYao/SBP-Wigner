%����������ѡȡ
hbar = 0.658211899;
me = 5.68562966;
m = 0.0665*me;



N = 257;%x�����������
M = 400;%k�����������
T = 5;%��ֹʱ��

xmin = -30;%x������߽�
xmax = 30;%x�����ұ߽�

kmin = -2.8;%k������߽�
kmax = 2.8;%k�����ұ߽�
% 
nt =1000*T+1;%ʱ�䷽������ڵ���



%x�����k������������

x = linspace(xmin,xmax,N);
k = linspace(kmin,kmax,M);
hx = (xmax-xmin)/(N-1);
hk = (kmax-kmin)/(M-1);




%y������������
% lenthK = kmax-kmin;
% dy = 2*pi/lenthK;
% lenthY = dy*(M-1);
% y = linspace(-lenthY/2,lenthY/2,M);

%ʱ�䷽��������ʷ�
% t = linspace(0,T,nt);
% %����2D������
% [X,K] = meshgrid ( x, k );

















%%%%%%%%%%%%%�ƺ���Ϊ��˹����ʱx�����������
%nk = 100 T = 10 nt = 10001 
xmin = -30;
xmax = 30;
kmin = -2.8;
kmax = 2.8;

nx = [32 64 128 256 512];
nx1  = [32 64 128 256 512 1025];
LL = 30;

[H1501,~,~,~,~] = UNDpEQ4_block(1501);
H1501 = LL*H1501;

[H1025,~,~,~,~] = UNDpEQ4_block(1025);
H1025 = LL*H1025;
[H513,~,~,~,~] = UNDpEQ4_block(513);
H513 = LL*H513;
% [H300,~,~,~,~] = UNDpEQ1(300);
% H300 = LL*H300;
[H257,~,~,~,~] = UNDpEQ4_block(257);
H257 = LL*H257;
[H129,~,~,~,~] = UNDpEQ4_block(129);
H129 = LL*H129;
[H65,~,~,~,~] = UNDpEQ4_block(65);
H65 = LL*H65;
[H33,~,~,~,~] = UNDpEQ4_block(33);
H33 = LL*H33;
[H17,~,~,~,~] = UNDpEQ4(17);
H17 = LL*H17;


k1  = linspace(kmin,kmax,101);
hk1 = (kmax-kmin)/100;
k1 = k1-hk1/2;
k1(1) = [];

k  = linspace(kmin,kmax,51);
hk = (kmax-kmin)/50;
k = k-hk/2;
k(1) = [];


x_1501 = linspace(xmin,xmax,1501);
[X_1501,K_1501] = meshgrid ( x_1501, k );

x_1025 = linspace(xmin,xmax,1025);
[X_1025,K_1025] = meshgrid ( x_1025, k );



x_513 = linspace(xmin,xmax,513);
[X_513,K_513] = meshgrid ( x_513, k );

x_300 = linspace(xmin,xmax,300);
[X_300,K_300] = meshgrid ( x_300, k );

x_257 = linspace(xmin,xmax,257);
[X_257,K_257] = meshgrid ( x_257, k );

x_129 = linspace(xmin,xmax,129);
[X_129,K_129] = meshgrid ( x_129, k );

x_65 = linspace(xmin,xmax,65);
[X_65,K_65] = meshgrid ( x_65, k );

x_33 = linspace(xmin,xmax,33);
[X_33,K_33] = meshgrid ( x_33, k );



% F_sbp_1501 = load('13_10001_nx1501_nk100_blocksbp4_k4_5.txt','%f');
% F_sbp_1501 = reshape ( F_sbp_1501 , 100 , 1501 );



F_sbp_1025 = load('13_5001_nx1025_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_1025 = reshape ( F_sbp_1025 , 50 , 1025 );
F_sbp_1025_100_inter1501 = interp2(X_1025,K_1025,F_sbp_1025,X_1501,K_1501,'spline');


F_sbp_513 = load('13_5001_nx513_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_513 = reshape ( F_sbp_513 , 50 , 513 );
F_sbp_513_inter1025_half = F_sbp_1025(:,1:2:end);
F_sbp_513_inter_half = F_sbp_1025(:,1:2:end);
F_sbp_513_100_inter1025 = interp2(X_513,K_513,F_sbp_513,X_1025,K_1025,'spline');
F_sbp_513_100_inter1501 = interp2(X_513,K_513,F_sbp_513,X_1501,K_1501,'spline');


F_sbp_257 = load('13_5001_nx257_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_257 = reshape ( F_sbp_257 , 50 , 257 );
F_sbp_257_inter1025_half = F_sbp_1025(:,1:4:end);
F_sbp_257_inter_half = F_sbp_513(:,1:2:end);
F_sbp_257_100_inter1025 = interp2(X_257,K_257,F_sbp_257,X_1025,K_1025,'spline');
F_sbp_257_100_inter1501 = interp2(X_257,K_257,F_sbp_257,X_1501,K_1501,'spline');


% F_sbp_300 = load('13_5001_nx300_nk50_blocksbp1_k4_5.txt','%f');
% F_sbp_300 = reshape ( F_sbp_300 , 50 , 300 );
% F_sbp_300_100_inter1025 = interp2(X_300,K_300,F_sbp_300,X_1025,K_1025,'spline');



F_sbp_129 = load('13_5001_nx129_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_129 = reshape ( F_sbp_129 , 50 , 129 );
F_sbp_129_inter1025_half = F_sbp_1025(:,1:8:end);
F_sbp_129_inter_half = F_sbp_257(:,1:2:end);
F_sbp_129_100_inter1025 = interp2(X_129,K_129,F_sbp_129,X_1025,K_1025,'spline');
F_sbp_129_100_inter1501 = interp2(X_129,K_129,F_sbp_129,X_1501,K_1501,'spline');


F_sbp_65 = load('13_5001_nx65_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_65 = reshape ( F_sbp_65 , 50 , 65 );
F_sbp_65_inter1025_half = F_sbp_1025(:,1:16:end);
F_sbp_65_inter_half = F_sbp_129(:,1:2:end);
F_sbp_65_100_inter1025 = interp2(X_65,K_65,F_sbp_65,X_1025,K_1025,'spline');
F_sbp_65_100_inter1501 = interp2(X_65,K_65,F_sbp_65,X_1501,K_1501,'spline');

F_sbp_33 = load('13_5001_nx33_nk50_blocksbp4_k4_5.txt','%f');
F_sbp_33 = reshape ( F_sbp_33 , 50 , 33 );
F_sbp_33_inter1025_half = F_sbp_1025(:,1:32:end);
F_sbp_33_inter_half = F_sbp_65(:,1:2:end);
F_sbp_33_100_inter1025 = interp2(X_33,K_33,F_sbp_33,X_1025,K_1025,'spline');
F_sbp_33_100_inter1501 = interp2(X_33,K_33,F_sbp_33,X_1501,K_1501,'spline');
% size(F_sbp_33_100_inter1501)


e1 = F_sbp_33-F_sbp_33_inter1025_half;
e11 = sqrt(trace(e1*H33*e1')*(5.6/50));
e111 = max(max(abs(e1)));


e2 = F_sbp_65-F_sbp_65_inter1025_half;
e22 = sqrt(trace(e2*H65*e2')*(5.6/50));
e222 = max(max(abs(e2)));

e3 = F_sbp_129-F_sbp_129_inter1025_half;
e33 = sqrt(trace(e3*H129*e3')*(5.6/50));
e333 = max(max(abs(e3)));

e4 = F_sbp_257-F_sbp_257_inter1025_half;
e44 = sqrt(trace(e4*H257*e4')*(5.6/50));
e444 = max(max(abs(e4)));


% e300 = F_sbp_1025-F_sbp_300_100_inter1025;
% ee300 = sqrt(trace(e300*H1025*e300')*(5.6/100));
% eee300 = max(max(abs(e300)));

e5 = F_sbp_513-F_sbp_513_inter1025_half;
e55 = sqrt(trace(e5*H513*e5')*(5.6/50));
e555 = max(max(abs(e5)));




% E1 = F_sbp_33_100_inter1501 - F_sbp_1501;
% EE1 = sqrt(trace(E1*H1501*E1')*(5.6/100));
% 
% 
% E2 = F_sbp_65_100_inter1501 - F_sbp_1501;
% EE2 = sqrt(trace(E2*H1501*E2')*(5.6/100));
% 
% 
% E3 = F_sbp_129_100_inter1501 - F_sbp_1501;
% EE3 = sqrt(trace(E3*H1501*E3')*(5.6/100));
% 
% 
% 
% E4 = F_sbp_257_100_inter1501 - F_sbp_1501;
% EE4 = sqrt(trace(E4*H1501*E4')*(5.6/100));
% 
% 
% E5 = F_sbp_513_100_inter1501 - F_sbp_1501;
% EE5 = sqrt(trace(E5*H1501*E5')*(5.6/100));
% 
% 
% E6 = F_sbp_1025_100_inter1501 - F_sbp_1501;
% EE6 = sqrt(trace(E6*H1501*E6')*(5.6/100));



ee1 = F_sbp_33_inter_half - F_sbp_33;
ee11 = sqrt(trace(ee1*H33*ee1')*(5.6/50));


ee2 = F_sbp_65_inter_half - F_sbp_65;
ee22 = sqrt(trace(ee2*H65*ee2')*(5.6/50));


ee3 = F_sbp_129_inter_half - F_sbp_129;
ee33 = sqrt(trace(ee3*H129*ee3')*(5.6/50));


ee4 = F_sbp_257_inter_half - F_sbp_257;
ee44 = sqrt(trace(ee4*H257*ee4')*(5.6/50));


ee5 = F_sbp_513_inter_half - F_sbp_513;
ee55 = sqrt(trace(ee5*H513*ee5')*(5.6/50));


error = [e11,e22,e33,e44,e55];
error
error1 = [ee11 ee22 ee33 ee44 ee55];
error1
order = [log2(e11/e22),log2(e22/e33),log2(e33/e44),log2(e44/e55)];


order1 = [log2(ee11/ee22), log2(ee22/ee33)  log2(ee33/ee44) log2(ee44/ee55) ];



% error1 = [EE1 EE2 EE3 EE4 EE5 EE6];
% 
% E_diag1 = [0.785497109312718   0.256158566546536   0.066107660660040   0.017371010031492   0.006761606651142   0.005416057664190];
% 
% 
% figure
% loglog(nx1,E_diag1,'.-')
% hold on 
% loglog(nx1,error1,'o-')
% hold on 
% loglog(nx,error_diag3_nk50_nt5001,'*-')
% hold on 
% loglog(nx,error_block3_nk50_nt5001,'+-')
% hold on
% loglog(nx,error_diag1_nk50_nt5001,'<-')
% hold on
% loglog(nx,error_diag4_nk50_nt5001,'>-')
% hold on
% loglog(nx1,error1,'p-')




error_diag1_nk50_nt5001 = [0.786127342674982   0.255401304052567   0.064873754962186   0.015454684266516   0.003091185383738];
error1_diag1_nk50_nt5001 = [0.631572758939588   0.196170884296482   0.049601296571273   0.012374044153698   0.003091185383738];

error_diag2_nk150_nt10001 = [0.403554420100516   0.037306329034948   0.002534259903324   0.000167262373101   0.000011303423252];

error_diag2_nk50_nt5001 = [0.232992173261895   0.021538750130229   0.001463040360091   0.000096515566440   0.000006538136680];
error1_diag2_nk50_nt5001 = [ 0.218674104046646   0.020144531913755   0.001369108193107   0.000090305049247   0.000006538136680];


error_block2_nk50_nt5001 = [0.228030038159402   0.021455448820975   0.001421342148711   0.000090000845130   0.000005359583183];
error1_block2_nk50_nt5001 = [0.214489842767220   0.020063658443032   0.001331611792731   0.000084747881023   0.000005359583183];

error_diag3_nk50_nt5001 = [0.169203583097614   0.007445239894964   0.000244951686380   0.000011839854836   0.000000761094384];
error1_diag3_nk50_nt5001 = [0.167491167581686   0.007340225236456   0.000238990939026   0.000011607423005   0.000000761094384];

error_block3_nk50_nt5001 = [0.095193817429113   0.002767506878209   0.000048796321565   0.000000954581512   0.000000038435572];
error1_block3_nk50_nt5001 = [0.093695288384777   0.002719434123823   0.000048115191758   0.000000950868637   0.000000038435572];

error_diag4_nk50_nt5001 = [0.224255934269499   0.009551225855936   0.000179084637446   0.000004884918868   0.000000260584689];
error1_diag4_nk50_nt5001 =[ 0.223505585962703   0.009515149500316   0.000177668927328   0.000004845182057   0.000000260584689];

error_block4_nk100_nt10001 = [ 0.071524372283028   0.000734282423213   0.000003433600087   0.000000168592377   0.000000001145886];
error1_block4_nk100_nt10001 = [ 0.071351911520184   0.000731038875493   0.000003430122361   0.000000168584484   0.000000001145886];


% order2 = zeros(1,4);
% for i = 1:4
%     order2(1,i) = log2(error1_block4_nk100_nt10001(i)/error1_block4_nk100_nt10001(i+1));
% end
% order2

figure
loglog(nx,error1_diag1_nk50_nt5001,'.-')
hold on 
loglog(nx,error1_diag2_nk50_nt5001,'ro-')
hold on 
loglog(nx,error1_block2_nk50_nt5001,'r*-')
hold on 
loglog(nx,error1_diag3_nk50_nt5001,'b+-')
hold on
loglog(nx,error1_block3_nk50_nt5001,'b<-')
hold on
loglog(nx,error1_diag4_nk50_nt5001,'g>-')
hold on
loglog(nx,error1_block4_nk100_nt10001,'gp-')
hold on
loglog(nx,error1,'kp-')
xlabel('nx')
ylabel('||e||_{sbp}')
legend('diagsbp1','diagsbp2','blocksbp2','diagsbp3','blocksbp3','diagsbp4','blocksbp4_{nt=10001}','blocksbp4_{nt=5001}')





%wkb�ı���ʽ

function  Fval = F_exact(x,k,t)
hbar = 0.658211899;
me = 5.68562966;
m = 0.0665*me;
a = 2.825;
k0 = 1.4;
x0 = -30;
v0 = hbar*k0/m;
beta = hbar/(2*m*a*a);
Fval = 2*exp(-(x-x0-v0*t).^2/(2*a^2*(1+beta^2*t.*t))).*...
    exp(-2*a^2*(1+beta^2*t.^2)*((k-k0)-beta*t*(x-x0-v0*t)/(2*a^2*(1+beta^2*t.^2))).^2);
end


