%����������ѡȡ

hbar = 1;
me = 1;
m = 1;


%�������ѡȡ
nu = 100;%�׷�������������
deg = 2;%sbp��
N =65;%x�����������
M = 64;%k�����������
T = 2*pi;%��ֹʱ��

xmin = -5;%x������߽�
xmax = 5;%x�����ұ߽�

kmin = -5;%k������߽�
kmax = 5;%k�����ұ߽�


nt =2001;%ʱ�䷽������ڵ���
t = linspace(0,T,nt);

x = linspace(xmin,xmax,N);
dx = (xmax-xmin)/(N-1);

k  = linspace(kmin,kmax,M+1);
hk = (kmax-kmin)/M;
k = k-hk/2;
k(1) = [];

[X,K] = meshgrid ( x, k );





nx = [33 65 129 257 513];
nx_order = nx-1;

e_diagsbp1 = [ 0.023949395725084  0.006034575413108  0.001509631349076 3.774379438628039e-04 9.436087407279014e-05];
e_diagsbp2 = [0.004059656863737  2.783537754541143e-04 1.787158604545565e-05 1.124887164718198e-06 7.043122772514375e-08];
e_diagsbp3 = [ 0.001003156903402  1.955577959494450e-05  3.245858261331820e-07 5.149956357127569e-09  8.301804660806918e-11];
e_diagsbp4 = [3.156515281631428e-04  1.812062513149734e-06 7.858086485992958e-09 3.689096522781507e-11 1.915964248918062e-11];
e_blocksbp2 = [0.004059656863177  2.783537754537880e-04  1.787158604545528e-05 1.124887164746910e-06 7.043122771929807e-08];
e_blocksbp3 = [0.001003157666554  1.955577956124420e-05  3.245858249193890e-07  5.149956324647626e-09  8.301804253206803e-11];
e_blocksbp4 = [3.143166564146580e-04 1.811960372536952e-06 7.857778289920454e-09  3.688350791084041e-11  1.915964166708991e-11];
%e_up1 = [0.073247365072260   0.040725936398779   0.021663155040126  0.011203179013397  0.005701409336701];
% 
% 
% e = e_diagsbp4;
% order1 = zeros(1,4);
% for i = 1:4
%     order1(1,i) = log(e(i+1)/e(i))/log(nx_order(i)/nx_order(i+1));
% end
% order1

figure
loglog(nx,e_diagsbp1,'k.-','DisplayName',{'dSBP$_1$'})
hold on 
loglog(nx,e_diagsbp2,'bo','DisplayName',{'dSBP$_2$'})
loglog(nx,e_diagsbp3,'r*','DisplayName',{'dSBP$_3$'})
loglog(nx(1:end),e_diagsbp4(1:end),'+','DisplayName',{'dSBP$_4$'})
loglog(nx,e_blocksbp2,'g--','DisplayName',{'bSBP$_2$'})
loglog(nx,e_blocksbp3,'c-d','DisplayName',{'bSBP$_3$'})
loglog(nx(1:end),e_blocksbp4(1:end),'m<-','DisplayName',{'bSBP$_4$'})
%hold on 
%loglog(nx,e_up1,'<-')
xlabel({'$N_x$'},'interpreter','latex','Fontsize',16)
ylabel({'$e_h$'},'interpreter','latex','Fontsize',16)
h1 = legend('show')
set(h1,'Interpreter','latex')
set(h1,'Fontsize',16)
hold off







