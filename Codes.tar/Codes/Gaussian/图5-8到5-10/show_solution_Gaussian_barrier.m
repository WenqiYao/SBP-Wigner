%����������ѡȡ
hbar = 0.658211899;
me = 5.68562966;
m = 0.0665*me;



N = 257;%x�����������
M = 400;%k�����������
T = 5;%��ֹʱ��

xmin = -30;%x������߽�
xmax = 30;%x�����ұ߽�

kmin = -2.8;%k������߽�
kmax = 2.8;%k�����ұ߽�
% 
nt =1000*T+1;%ʱ�䷽������ڵ���



%x�����k������������

x = linspace(xmin,xmax,N);
k = linspace(kmin,kmax,M);
hx = (xmax-xmin)/(N-1);
hk = (kmax-kmin)/(M-1);




%y������������
% lenthK = kmax-kmin;
% dy = 2*pi/lenthK;
% lenthY = dy*(M-1);
% y = linspace(-lenthY/2,lenthY/2,M);

%ʱ�䷽��������ʷ�
% t = linspace(0,T,nt);
% %����2D������
% [X,K] = meshgrid ( x, k );










%%%%%%%%%%%%%%%%%K���������������

%nx = 257 T = 10 nt = 10001 blocksbp4

NKK = (40:40:200);
NK = [20 24 28 32 36];

k100 = linspace(kmin,kmax,101);
hk100 = (kmax-kmin)/100;
k100 = k100-hk100/2;
k100(1) = [];
[X100,K100] = meshgrid ( x, k100 );

k20 = linspace(kmin,kmax,21);
hk20 = (kmax-kmin)/20;
k20 = k20-hk20/2;
k20(1) = [];
[X20,K20] = meshgrid ( x, k20 );

k24 = linspace(kmin,kmax,25);
hk24 = (kmax-kmin)/24;
k24 = k24-hk24/2;
k24(1) = [];
[X24,K24] = meshgrid ( x, k24 );

k28 = linspace(kmin,kmax,29);
hk28 = (kmax-kmin)/28;
k28 = k28-hk28/2;
k28(1) = [];
[X28,K28] = meshgrid ( x, k28 );

k32 = linspace(kmin,kmax,33);
hk32 = (kmax-kmin)/32;
k32 = k32-hk32/2;
k32(1) = [];
[X32,K32] = meshgrid ( x, k32 );


k36 = linspace(kmin,kmax,37);
hk36 = (kmax-kmin)/36;
k36 = k36-hk36/2;
k36(1) = [];
[X36,K36] = meshgrid ( x, k36 );


F_blocksbp4_Vguass_257_100 = load('23_10001_nx257_nk100_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_100 = reshape ( F_blocksbp4_Vguass_257_100 , 100 , 257 );



F_blocksbp4_Vguass_257_20 = load('23_10001_nx257_nk20_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_20 = reshape ( F_blocksbp4_Vguass_257_20 , 20 , 257 );
F_diagsbp4_Vguass_257_20_inter100 = interp2(X20,K20,F_blocksbp4_Vguass_257_20,X100,K100,'spline');



F_blocksbp4_Vguass_257_24 = load('23_10001_nx257_nk24_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_24 = reshape ( F_blocksbp4_Vguass_257_24 , 24 , 257 );
F_diagsbp4_Vguass_257_24_inter100 = interp2(X24,K24,F_blocksbp4_Vguass_257_24,X100,K100,'spline');


F_blocksbp4_Vguass_257_28 = load('23_10001_nx257_nk28_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_28 = reshape ( F_blocksbp4_Vguass_257_28 , 28 , 257 );
F_diagsbp4_Vguass_257_28_inter100 = interp2(X28,K28,F_blocksbp4_Vguass_257_28,X100,K100,'spline');



F_blocksbp4_Vguass_257_32 = load('23_10001_nx257_nk32_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_32 = reshape ( F_blocksbp4_Vguass_257_32 , 32 , 257 );
F_diagsbp4_Vguass_257_32_inter100 = interp2(X32,K32,F_blocksbp4_Vguass_257_32,X100,K100,'spline');

F_blocksbp4_Vguass_257_36 = load('23_10001_nx257_nk36_blocksbp4_k4.txt','%f');
F_blocksbp4_Vguass_257_36 = reshape ( F_blocksbp4_Vguass_257_36 , 36 , 257 );
F_diagsbp4_Vguass_257_36_inter100 = interp2(X36,K36,F_blocksbp4_Vguass_257_36,X100,K100,'spline');


[H,~,~,~,~] = UNDpEQ4_block(N);
H = 5.6/2*H;

e1 = F_diagsbp4_Vguass_257_20_inter100-F_blocksbp4_Vguass_257_100; 
e11 = sqrt(trace(e1*H*e1')*5.6/100);
e111 = max(max(abs(e1)));

e2 = F_diagsbp4_Vguass_257_24_inter100-F_blocksbp4_Vguass_257_100; 
e22 = sqrt(trace(e2*H*e2')*5.6/100);
e222 = max(max(abs(e2)));

e3 = F_diagsbp4_Vguass_257_28_inter100-F_blocksbp4_Vguass_257_100; 
e33 = sqrt(trace(e3*H*e3')*5.6/100);
e333 = max(max(abs(e3)));

e4 = F_diagsbp4_Vguass_257_32_inter100-F_blocksbp4_Vguass_257_100; 
e44 = sqrt(trace(e4*H*e4')*5.6/100);
e444 = max(max(abs(e4)));

e5 = F_diagsbp4_Vguass_257_36_inter100-F_blocksbp4_Vguass_257_100; 
e55 = sqrt(trace(e5*H*e5')*5.6/100);
e555 = max(max(abs(e5)));

%  

 







 

error = [e11,e22,e33,e44,e55];
error1 = [e111 e222 e333 e444 e555];
error1
error

e23 = [0.161665652884093   0.097349868697446   0.057147454179220   0.029747683553360   0.013630824196900];
e13 = [0.175327476441302   0.098381684769128   0.056184433082584   0.032967971130880   0.017254603367084];
e03 = [0.151615260525496   0.089487451745746   0.052330107524970   0.031416704238432   0.019102491749632];


figure
plot(NK,log(error1),'.-')
hold on
plot(NK,log(error),'o-')
% hold on
% plot(NK,log(e03),'*-')
xlabel('nk')
ylabel('log10(||e||)')
legend('L_{\infty}����','L_{sbp}����')
% hold on
% plot(NKK,log(error5),'o-')
% hold on
% plot(NKK,log(error6),'*-')
% xlabel('nk')
% ylabel('norm e')
% legend('diag4-nx=257','diag4-nx=513','diag4-nx=513-h=2.3','Location','SouthEast')















function  Fval = F_exact(x,k,t)
hbar = 0.658211899;
me = 5.68562966;
m = 0.0665*me;
a = 2.825;
k0 = 1.4;
x0 = -30;
v0 = hbar*k0/m;
beta = hbar/(2*m*a*a);
Fval = 2*exp(-(x-x0-v0*t).^2/(2*a^2*(1+beta^2*t.*t))).*...
    exp(-2*a^2*(1+beta^2*t.^2)*((k-k0)-beta*t*(x-x0-v0*t)/(2*a^2*(1+beta^2*t.^2))).^2);
end


