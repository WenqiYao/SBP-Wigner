function[F,X,K,H] = winger_sbp_fft_Harmonic_oscillator(N,M,T,xmin,xmax,kmin,kmax,nt,F_exact,V,g_l,g_r,deg)
%�������ɺͼ��㲽��

x = linspace(xmin,xmax,N);
dx = (xmax-xmin)/(N-1);


k  = linspace(kmin,kmax,M+1);
hk = (kmax-kmin)/M;
k = k-hk/2;
k(1) = [];

[X,K] = meshgrid ( x, k );

dt = T/(nt-1);


%ѡ��sbp����
if deg == 1
    [H,D,~,~,~] = UNDpEQ1(N);
elseif deg == 2
    [H,D,~,~,~] = UNDpEQ2(N);
elseif deg == 3
    [H,D,~,~,~] = UNDpEQ3(N);
elseif deg == 4
    [H,D,~,~,~] = UNDpEQ4(N);
elseif deg == 5
    [H,D,~,~,~] = UNDpEQ2_block(N);
elseif deg == 6
    [H,D,~,~,~] = UNDpEQ3_block(N);
elseif deg == 7
    [H,D,~,~,~] = UNDpEQ4_block(N);
end

D = 2/(xmax-xmin)*D;
H = (xmax-xmin)/2*H;


%y������������
lenthK = kmax-kmin;
dy = 2*pi/lenthK;
lenthY = dy*(M-1);
y = linspace(-lenthY/2,lenthY/2,M);


%��������
hbar = 1;
m = 1;


%SATǰϵ��
sigma = -5.5;



%��ֵ��ɢ
F = zeros(M,N,nt);
F(:,:,1) = F_exact(X,K,0);




for i = 1:nt-1
    t = (i-1)*dt;
    
    tt = (i-1)*dt;
    F1right = F(:,:,i);
    
    F_convection = zeros(M,N);
    for j = 1:M
        F_convection(j,:) =hbar/m*k(j)*F1right(j,:)*D';      
    end
    F_pseudo = zeros(M,N);
    for p = 1:N
        D_v = V(x(p)-y/2)-V(x(p)+y/2);
        F1 = F1right(:,p);
        F2 = zeros(M,1);
        F2(1:M/2,1) = F1(M/2+1:end,1);
        F2(M/2+1:end,1) = F1(1:M/2,1);
        Fhat = ifft(F2);
        D_v1 = zeros(1,M);
        D_v1(1,1:M/2) = D_v(1,M/2+1:end);
        D_v1(1,M/2+1:end) = D_v(1,1:M/2);
        F_pseudo1 = sqrt(-1)/hbar*fft(Fhat.*D_v1');
        F_pseudo2 = zeros(M,1);
        F_pseudo2(1:M/2,1) = F_pseudo1(M/2+1:end,1);
        F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2,1);
        F_pseudo(:,p)= F_pseudo2;        
    end
    
    
    SAT1 = zeros(M,N);
    SAT1(M/2+1:end,1) = F1right(M/2+1:end,1)-F_exact(xmin,k(M/2+1:end),tt)';
%     SAT1(:,1) =  SAT1(:,1).*sigma_l;
    SAT2 = zeros(M,N);
    SAT2(1:M/2,end) = F1right(1:M/2,end)-F_exact(xmax,k(1:M/2),tt)';
%     SAT2(:,end) = SAT2(:,end).*sigma_r;
    
    K1 = -F_convection+real(F_pseudo)+sigma*SAT1/H+sigma*SAT2/H;
    
    tt = t+dt/3;
    F2right = F1right+dt/3*K1;
    
    F_convection = zeros(M,N);
    for j = 1:M
        F_convection(j,:)=hbar/m*k(j)*F2right(j,:)*D';      
    end
    F_pseudo = zeros(M,N);
    for p = 1:N
        D_v = V(x(p)-y/2)-V(x(p)+y/2);
        F1 = F2right(:,p);
        F2 = zeros(M,1);
        F2(1:M/2,1) = F1(M/2+1:end,1);
        F2(M/2+1:end,1) = F1(1:M/2,1);
        Fhat = ifft(F2);
        D_v1 = zeros(1,M);
        D_v1(1,1:M/2) = D_v(1,M/2+1:end);
        D_v1(1,M/2+1:end) = D_v(1,1:M/2);
        F_pseudo1 = sqrt(-1)/hbar*fft(Fhat.*D_v1');
        F_pseudo2 = zeros(M,1);
        F_pseudo2(1:M/2,1) = F_pseudo1(M/2+1:end,1);
        F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2,1);
        F_pseudo(:,p)= F_pseudo2;        
    end
    
    SAT1 = zeros(M,N);
    SAT1(M/2+1:end,1) = F2right(M/2+1:end,1)-F_exact(xmin,k(M/2+1:end),tt)';
%     SAT1(:,1) =  SAT1(:,1).*sigma_l;
    SAT2 = zeros(M,N);
    SAT2(1:M/2,end) = F2right(1:M/2,end)-F_exact(xmax,k(1:M/2),tt)';
%     SAT2(:,end) = SAT2(:,end).*sigma_r;
    
    K2 = -F_convection+real(F_pseudo)+sigma*SAT1/H+sigma*SAT2/H;
    
    tt = t+dt*2/3;
    F3right = F1right-dt/3*K1+dt*K2;
    
    F_convection = zeros(M,N);
    for j = 1:M
        F_convection(j,:) =hbar/m*k(j)*F3right(j,:)*D';      
    end
     F_pseudo = zeros(M,N);
    for p = 1:N
        D_v = V(x(p)-y/2)-V(x(p)+y/2);
        F1 = F3right(:,p);
        F2 = zeros(M,1);
        F2(1:M/2,1) = F1(M/2+1:end,1);
        F2(M/2+1:end,1) = F1(1:M/2,1);
        Fhat = ifft(F2);
        D_v1 = zeros(1,M);
        D_v1(1,1:M/2) = D_v(1,M/2+1:end);
        D_v1(1,M/2+1:end) = D_v(1,1:M/2);
        F_pseudo1 = sqrt(-1)/hbar*fft(Fhat.*D_v1');
        F_pseudo2 = zeros(M,1);
        F_pseudo2(1:M/2,1) = F_pseudo1(M/2+1:end,1);
        F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2,1);
        F_pseudo(:,p)= F_pseudo2;        
    end
    SAT1 = zeros(M,N);
    SAT1(M/2+1:end,1) = F3right(M/2+1:end,1)-F_exact(xmin,k(M/2+1:end),tt)';
%     SAT1(:,1) =  SAT1(:,1).*sigma_l;
    SAT2 = zeros(M,N);
    SAT2(1:M/2,end) = F3right(1:M/2,end)-F_exact(xmax,k(1:M/2),tt)';
%     SAT2(:,end) = SAT2(:,end).*sigma_r;
   
    
    K3 = -F_convection+real(F_pseudo)+sigma*SAT1/H+sigma*SAT2/H;
    
    
    tt = t+dt;
    F4right = F1right+dt*K1-dt*K2+dt*K3;
    
    F_convection = zeros(M,N);
    for j = 1:M
        F_convection(j,:) =hbar/m*k(j)*F4right(j,:)*D';      
    end
     F_pseudo = zeros(M,N);
    for p = 1:N
        D_v = V(x(p)-y/2)-V(x(p)+y/2);
        F1 = F4right(:,p);
        F2 = zeros(M,1);
        F2(1:M/2,1) = F1(M/2+1:end,1);
        F2(M/2+1:end,1) = F1(1:M/2,1);
        Fhat = ifft(F2);
        D_v1 = zeros(1,M);
        D_v1(1,1:M/2) = D_v(1,M/2+1:end);
        D_v1(1,M/2+1:end) = D_v(1,1:M/2);
        F_pseudo1 = sqrt(-1)/hbar*fft(Fhat.*D_v1');
        F_pseudo2 = zeros(M,1);
        F_pseudo2(1:M/2,1) = F_pseudo1(M/2+1:end,1);
        F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2,1);
        F_pseudo(:,p)= F_pseudo2;        
    end
    SAT1 = zeros(M,N);
    SAT1(M/2+1:end,1) = F4right(M/2+1:end,1)-F_exact(xmin,k(M/2+1:end),tt)';
%     SAT1(:,1) =  SAT1(:,1).*sigma_l;
    SAT2 = zeros(M,N);
    SAT2(1:M/2,end) = F4right(1:M/2,end)-F_exact(xmax,k(1:M/2),tt)';
%     SAT2(:,end) = SAT2(:,end).*sigma_r;
   
    
    K4 = -F_convection+real(F_pseudo)+sigma*SAT1/H+sigma*SAT2/H;
    
    F(:,:,i+1) = F(:,:,i)+dt/8*(K1+3*K2+3*K3+K4);
       
    
end




% for i = 1:nt-1
%     t = (i-1)*dt;
%     
%     tt = (i-1)*dt;
%     F1right = F(:,:,i);
%     
%     F_convection = zeros(M+1,N);
%     for j = 1:M+1
%         F_convection(j,:) =p(j)*F1right(j,:)*D';      
%     end
%     F_pseudo = zeros(M+1,N);
%     for k = 1:N
%         D_v = V(x(k)-y/2)-V(x(k)+y/2);
%         F1 = F1right(:,k);
%         F2 = zeros(M+1,1);
%         F2(1:M/2+1,1) = F1(M/2+1:end,1);
%         F2(M/2+2:end,1) = F1(1:M/2,1);
%         Fhat = ifft(F2);
%         D_v1 = zeros(1,M+1);
%         D_v1(1,1:M/2+1) = D_v(1,M/2+1:end);
%         D_v1(1,M/2+2:end) = D_v(1,1:M/2);
%         F_pseudo1 = sqrt(-1)*fft(Fhat.*D_v1');
%         F_pseudo2 = zeros(M+1,1);
%         F_pseudo2(1:M/2,1) = F_pseudo1(M/2+2:end,1);
%         F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2+1,1);
%         F_pseudo(:,k)= F_pseudo2;        
%     end
%     SAT1 = zeros(M+1,N);
%     SAT1(M/2+2:end,1) = F1right(M/2+2:end,1)-g_l(p(M/2+2:end),tt)';
%     SAT2 = zeros(M+1,N);
%     SAT2(1:M/2,end) = F1right(1:M/2,end)-g_r(p(1:M/2),tt)';
%     
%     K1 = -F_convection+real(F_pseudo)+sigma_l*SAT1/H(1,1)+sigma_r*SAT2/H(end,end);
%     
%     tt = t+dt/2;
%     F2right = F1right+dt/2*K1;
%     
%     F_convection = zeros(M+1,N);
%     for j = 1:M+1
%         F_convection(j,:) =p(j)*F2right(j,:)*D';      
%     end
%     F_pseudo = zeros(M+1,N);
%     for k = 1:N
%         D_v = V(x(k)-y/2)-V(x(k)+y/2);
%         F1 = F2right(:,k);
%         F2 = zeros(M+1,1);
%         F2(1:M/2+1,1) = F1(M/2+1:end,1);
%         F2(M/2+2:end,1) = F1(1:M/2,1);
%         Fhat = ifft(F2);
%         D_v1 = zeros(1,M+1);
%         D_v1(1,1:M/2+1) = D_v(1,M/2+1:end);
%         D_v1(1,M/2+2:end) = D_v(1,1:M/2);
%         F_pseudo1 = sqrt(-1)*fft(Fhat.*D_v1');
%         F_pseudo2 = zeros(M+1,1);
%         F_pseudo2(1:M/2,1) = F_pseudo1(M/2+2:end,1);
%         F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2+1,1);
%         F_pseudo(:,k)= F_pseudo2;        
%     end
%     SAT1 = zeros(M+1,N);
%     SAT1(M/2+2:end,1) = F2right(M/2+2:end,1)-g_l(p(M/2+2:end),tt)';
%     SAT2 = zeros(M+1,N);
%     SAT2(1:M/2,end) = F2right(1:M/2,end)-g_r(p(1:M/2),tt)';
%     
%     K2 = -F_convection+real(F_pseudo)+sigma_l*SAT1/H(1,1)+sigma_r*SAT2/H(end,end);
%     
%     tt = t+dt;
%     F3right = F1right-dt*K1+2*dt*K2;
%     
%     F_convection = zeros(M+1,N);
%     for j = 1:M+1
%         F_convection(j,:) =p(j)*F3right(j,:)*D';      
%     end
%     F_pseudo = zeros(M+1,N);
%     for k = 1:N
%         D_v = V(x(k)-y/2)-V(x(k)+y/2);
%         F1 = F3right(:,k);
%         F2 = zeros(M+1,1);
%         F2(1:M/2+1,1) = F1(M/2+1:end,1);
%         F2(M/2+2:end,1) = F1(1:M/2,1);
%         Fhat = ifft(F2);
%         D_v1 = zeros(1,M+1);
%         D_v1(1,1:M/2+1) = D_v(1,M/2+1:end);
%         D_v1(1,M/2+2:end) = D_v(1,1:M/2);
%         F_pseudo1 = sqrt(-1)*fft(Fhat.*D_v1');
%         F_pseudo2 = zeros(M+1,1);
%         F_pseudo2(1:M/2,1) = F_pseudo1(M/2+2:end,1);
%         F_pseudo2(M/2+1:end,1) = F_pseudo1(1:M/2+1,1);
%         F_pseudo(:,k)= F_pseudo2;        
%     end
%     SAT1 = zeros(M+1,N);
%     SAT1(M/2+2:end,1) = F3right(M/2+2:end,1)-g_l(p(M/2+2:end),tt)';
%     SAT2 = zeros(M+1,N);
%     SAT2(1:M/2,end) = F3right(1:M/2,end)-g_r(p(1:M/2),tt)';
%     
%     K3 = -F_convection+real(F_pseudo)+sigma_l*SAT1/H(1,1)+sigma_r*SAT2/H(end,end);
%     
%     F(:,:,i+1) = F(:,:,i)+dt/6*(K1+4*K2+K3);
       
    
% end



end