%����������ѡȡ
beta =  38.6814933;% 1/eV
m0 =  5.69e-30;%eV*s^2*cm^-2
m = 0.0667*m0;
hbar =  6.582122020e-1;%��΢��������ǰ��ϵ������ȡ
mu =  0.07969610918933088;%eV
hbar1 =  1.0545726663;%������ǰ��ϵ������ȡ
m1 = 9.109389754*0.0667;%������ǰ��ϵ������ȡ
hbar2 =  6.582122020e-16;%�����ܶ�ǰ��ϵ������ȡeV*s
m2 = 5.69e-30*0.0667;%�����ܶ�ǰ��ϵ������ȡ��eV*s^2*nm^-2
q = 1.6021773349e-19;%���ӵ��


%ƫѹ��ѡȡ
ds = [0  -0.0125  -0.025  -0.0375  -0.05  -0.0625  -0.075  -0.0875  -0.1 -0.1125  -0.125 -0.1375 -0.15 -0.1625  -0.175 -0.1875  -0.2  -0.2125 -0.225 -0.2375 -0.25...
     -0.2625  -0.275  -0.2875  -0.3 -0.3125  -0.325  -0.3375  -0.35  -0.3625  -0.375  -0.3875  -0.4  -0.4125  -0.425  -0.4375 -0.45  -0.4625  -0.475  -0.4875  -0.5];
ds1 = linspace(0,0.5,41);
Vl = 0;
Vr = ds(1);

N = 81;
M = 64;

xmax = 45.2;
xmin = 0;
x = linspace(xmin,xmax,N);
x(50) = 27.685;
xx = linspace(xmin,xmax,161);
xx(99) = 27.685;
hx  =( xmax - xmin)/(N-1);
hy = 2*hx;
x_up = x(2:end);
x_up = x_up - hx/2;

kmax = pi/hy;
k  = linspace(-kmax,kmax,M+1);
hk = 2*kmax/M;
k = k-hk/2;
k(1) = [];
[X,K] = meshgrid ( x, k );



kk  = linspace(-2*kmax,2*kmax,M+1);
hkk = 4*kmax/M;
kk = kk-hkk/2;
kk(1) = [];




F_up1_1  = load('ds1_up1_nx81_nk64_nt30_T500.txt','%f');
F_up1_1= reshape ( F_up1_1,64,81 );


figure(1)
surf(X,K,F_up1_1(:,:))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�


F_up2_1  = load('ds1_up2_nx81_nk64_nt30_T500.txt','%f');
F_up2_1= reshape ( F_up2_1,64,83 );


figure(2)
surf(X,K,F_up2_1(:,2:end-1))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�


F_up3_1  = load('ds1_up3_nx81_nk64_nt30_T500.txt','%f');
F_up3_1= reshape ( F_up3_1,64,85 );


figure(3)
surf(X,K,F_up3_1(:,3:end-2))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�



F_sbp1_1  = load('ds1_diagsbp1_nx81_nk64_nt40_T700.txt','%f');
F_sbp1_1= reshape ( F_sbp1_1,64,81 );


figure(4)
surf(X,K,F_sbp1_1(:,:))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�


F_sbp2_1  = load('ds1_diagsbp2_nx81_nk64_nt40_T700.txt','%f');
F_sbp2_1= reshape ( F_sbp2_1,64,81 );


figure(5)
surf(X,K,F_sbp2_1(:,:))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�


F_sbp3_1  = load('ds1_diagsbp3_nx81_nk64_nt40_T700.txt','%f');
F_sbp3_1= reshape ( F_sbp3_1,64,81 );


figure(6)
surf(X,K,F_sbp3_1(:,:))
xlabel('{$x(nm)$}','interpreter','latex','fontsize',16)
ylabel('{$k(nm^{-1})$}','interpreter','latex','fontsize',16)
zlabel('{$f(cm^{-2})$}','interpreter','latex','fontsize',16)
set(gcf,'Renderer','ZBuffer')  %��ֹ�����eps��ȫ�ڵ�



F_iv_sbp1  = load('F_iv_500_sbp1_dt40.txt','%f');
F_iv_sbp1= reshape ( F_iv_sbp1,64,81,41 );


% figure
% surf(X,K,F_iv_sbp1(:,:,1))
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')



J_iv_sbp1 = zeros(1,41);
for ds = 1:41
    F_sbp1 = F_iv_sbp1(:,:,ds);
    JJ_sbp1 = zeros(1,N);
    for i = 1:N
        JJ_sbp1(1,i) = q*hbar2*hk/(2*pi*m2)*sum(F_sbp1(:,i).*k');
    end
    J_sbp1 = zeros(1,N-3);
    for i = 1:N-3
        J_sbp1(1,i) = 1/2*JJ_sbp1(i+1)+1/2*JJ_sbp1(i+2);
    end
    J_iv_sbp1(1,ds) = mean(J_sbp1); 
end







F_iv_sbp2  = load('F_iv_500_sbp2_dt40.txt','%f');
F_iv_sbp2= reshape ( F_iv_sbp2,64,81,41 );


% figure
% surf(X,K,F_iv_sbp2(:,:,1))
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')



J_iv_sbp2 = zeros(1,41);
for ds = 1:41
    F_sbp2 = F_iv_sbp2(:,:,ds);
    JJ_sbp2 = zeros(1,N);
    for i = 1:N
        JJ_sbp2(1,i) = q*hbar2*hk/(2*pi*m2)*sum(F_sbp2(:,i).*k');
    end
    J_sbp2 = zeros(1,N-7);
    for i = 1:N-7
        J_sbp2(1,i) = -1/12*JJ_sbp2(i+2)+7/12*JJ_sbp2(i+3)+7/12*JJ_sbp2(i+4)-1/12*JJ_sbp2(i+5);
    end
    J_iv_sbp2(1,ds) = mean(J_sbp2); 
end




F_iv_sbp3  = load('F_iv_500_sbp3_dt40.txt','%f');
F_iv_sbp3= reshape ( F_iv_sbp3,64,81,41 );


% figure
% surf(X,K,F_iv_sbp3(:,:,1))
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')



J_iv_sbp3 = zeros(1,41);
for ds = 1:41
    F_sbp3 = F_iv_sbp3(:,:,ds);
    JJ_sbp3 = zeros(1,N);
    for i = 1:N
        JJ_sbp3(1,i) = q*hbar2*hk/(2*pi*m2)*sum(F_sbp3(:,i).*k');
    end
    J_sbp3 = zeros(1,N-11);
    for i = 1:N-11
        J_sbp3(1,i) = 1/60*JJ_sbp3(i+3)-2/15*JJ_sbp3(i+4)+37/60*JJ_sbp3(i+5)+37/60*JJ_sbp3(i+6)-2/15*JJ_sbp3(i+7)+1/60*JJ_sbp3(i+8);
    end
    J_iv_sbp3(1,ds) = mean(J_sbp3); 
end





F_iv_sbp4  = load('F_iv_500_sbp4_dt40.txt','%f');
F_iv_sbp4= reshape ( F_iv_sbp4,64,81,41 );


% figure
% surf(X,K,F_iv_sbp4(:,:,1))
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')




J_iv_sbp4 = zeros(1,41);
for ds = 1:41
    F_sbp4 = F_iv_sbp4(:,:,ds);
    JJ_sbp4 = zeros(1,N);
    for i = 1:N
        JJ_sbp4(1,i) = q*hbar2*hk/(2*pi*m2)*sum(F_sbp4(:,i).*k');
    end
    J_sbp4 = zeros(1,N-15);
for i = 1:N-15
    J_sbp4(1,i) = -1/280*JJ_sbp4(i+4)+29/840*JJ_sbp4(i+5)-139/840*JJ_sbp4(i+6)+533/840*JJ_sbp4(i+7)+533/840*JJ_sbp4(i+8)-139/840*JJ_sbp4(i+9)+29/840*JJ_sbp4(i+10)-1/280*JJ_sbp4(i+11);
end
    J_iv_sbp4(1,ds) = mean(J_sbp4); 
end



F_iv  = load('F_iv_500_up1_dt20.txt','%f');
F_iv= reshape ( F_iv,64,81,41 );


% figure
% surf(X,K,F_iv(:,:,1))
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')


J_iv_up1 = zeros(1,41);
for ds = 1:41
    F_up = F_iv(:,:,ds);
    JJ_up = zeros(1,80);
    for i = 1:80
        JJ_up(i) = q*hbar2*2*hk/(2*pi*m2)*(sum(F_up(1:M/2,i+1).*k(1:M/2)')+sum(F_up(M/2+1:end,i).*k(M/2+1:end)'));
    end
    J_iv_up1(1,ds) = mean(JJ_up); 
end










F_iv_up2_dt40  = load('F_iv_2000_up2_dt40.txt','%f');
F_iv_up2_dt40= reshape (F_iv_up2_dt40 , M , 81, 41 );



J_iv_up2_dt40 = zeros(1,41);
for ds = 1:41
    F2_up2 = F_iv_up2_dt40(:,:,ds);
    JJ2_up2 = zeros(1,78);
    for i = 1:78
        JJ2_up2(1,i) = q*hbar2*hk/(2*pi*m2)*(sum((3/2*F2_up2(1:M/2,i+2)-1/2*F2_up2(1:M/2,i+3)).*k(1:M/2)')+sum((-1/2*F2_up2(M/2+1:end,i)+3/2*F2_up2(M/2+1:end,i+1)).*k(M/2+1:end)'));
    end
    J_iv_up2_dt40(1,ds) = mean(JJ2_up2); 
end
% 
% 
% F_iv_up3  = load('F_up3_200_up3out_dt40.txt','%f');
% F_iv_up3= reshape ( F_iv_up3,64,85,41 );
% 
% J_iv_up3 = zeros(1,41);
% for ds = 1:41
%     F_up3 = F_iv_up3(:,:,ds);
%     JJ_up3 = zeros(1,80);
%     for i = 1:N-1
%         JJ_up3(1,i) = q*hbar2*hk/(2*pi*m2)*(sum((11/6*F_up3(1:M/2,i+3)-7/6*F_up3(1:M/2,i+4)+1/3*F_up3(1:M/2,i+5)).*k(1:M/2)')+sum((1/3*F_up3(M/2+1:end,i)-7/6*F_up3(M/2+1:end,i+1)+11/6*F_up3(M/2+1:end,i+2)).*k(M/2+1:end)'));
%     end
%     J_iv_up3(1,ds) = mean(JJ_up3); 
% end



% Curr3 = zeros(1,41);
% 
% for v = 1:41
%     Vr = ds(v);
%     [F,~,~,k,~,~,hk,~] = winger_steady_upwind3_RTD(N,M,xmin,xmax,@V,@g,Vr,deg);
%     F = reshape ( F, M, N+4);
%     J = zeros(1,N-1);
%     for i = 1:N-1
%         J(1,i) = q*hbar2*hk/(2*pi*m2)*(sum((11/6*F(1:M/2,i+3)-7/6*F(1:M/2,i+4)+1/3*F(1:M/2,i+5)).*k(1:M/2)')+sum((1/3*F(M/2+1:end,i)-7/6*F(M/2+1:end,i+1)+11/6*F(M/2+1:end,i+2)).*k(M/2+1:end)'));
%     end
%     Curr3(1,v) = median(J);
% end




figure(7)
% plot(ds1,J_iv_up_2hx,'*-')
% hold on
plot(ds1,J_iv_up1,'c-d')
hold on
% plot(ds1,J_iv_up11,'.-')
% hold on 
plot(ds1,J_iv_up2_dt40,'r.-')
% plot(ds1,j_up_dt10,'.-')
% hold on
plot(ds1,J_iv_sbp1,'k*-')
plot(ds1,J_iv_sbp2,'b+-')
plot(ds1,J_iv_sbp3,'g-o')
plot(ds1,J_iv_sbp4,'p--')
xlabel({'Voltage$(eV)$'},'interpreter','latex','Fontsize',16)
ylabel({'Current$(Acm^{-2})$'},'interpreter','latex','Fontsize',16)
legend({'upwind$_1$'},{'upwind$_2$'},{'dSBP$_1$'},{'dSBP$_2$'},{'dSBP$_3$'},{'dSBP$_4$'})
h1 = legend('show')
set(h1,'Interpreter','latex')
set(h1,'Fontsize',16)
hold off






% figure
% surf(X,K,F_iv)
% xlabel('x(nm)')
% ylabel('k(nm^-1)')
% zlabel('f(cm^-2)')


% V1 = V(x,Vl,0);
% V2 = V(x,Vl,-0.1);
% V3 = V(x,Vl,-0.2);
% V4 = V(x,Vl,-0.3);
% V5 = V(x,Vl,-0.4);
% V6 = V(x,Vl,-0.5);
% figure
% plot(x,V1,'.-')
% hold on
% plot(x,V2,'o-')
% hold on
% plot(x,V3,'*-')
% hold on
% plot(x,V4,'+-')
% hold on
% plot(x,V5,'p-')
% hold on
% plot(x,V6,'>-')
% xlabel('nm')
% ylabel('ev')
% legend('ƫѹ=0','ƫѹ=-0.1','ƫѹ=-0.2','ƫѹ=-0.3','ƫѹ=-0.4','ƫѹ=-0.5')


 

function Vval = V(x,Vl,Vr)%�ƺ���
VV = 0.27;
V0val = VV.*(17.515<=x&x<=20.34)+VV.*(24.86<=x&x<=27.685)+0.*(x<17.515|x>27.685)+0.*(20.34<x&x<24.86);
Vdsval = Vl.*(x<17.515)+Vr.*(x>27.685)+((Vr-Vl)/10.17.*x+((27.685)*Vl-(17.515)*Vr)/10.17).*(17.515<=x&x<=27.685);
Vval = V0val+Vdsval;
end


function g_val = g(k)
beta =  38.6814933;
m0 =  5.69e-30;
m = 0.0665*m0;
hbar =  6.582122020e-16;
mu =  0.07969610918933088;
g_val = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
end


function f0_exact_val = f0_exact(x,k)
beta =  38.6814933;
m0 =  5.69e-30;
m = 0.0665*m0;
hbar =  6.582122020e-16;
mu =  0.07969610918933088;
if x <=0&&k>0
   f0_exact_val  = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
elseif x >=45.2&&k<0
   f0_exact_val  = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
else
    f0_exact_val = 0;
end
end


