%����������ѡȡ
beta =  38.6814933;% 1/eV
m0 =  5.69e-30;%eV*s^2*cm^-2
m = 0.0667*m0;
hbar =  6.582122020e-1;%��΢��������ǰ��ϵ������ȡ
mu =  0.07969610918933088;%eV
hbar1 =  1.0545726663;%������ǰ��ϵ������ȡ
m1 = 9.109389754*0.0667;%������ǰ��ϵ������ȡ
hbar2 =  6.582122020e-16;%�����ܶ�ǰ��ϵ������ȡeV*s
m2 = 5.69e-30*0.0667;%�����ܶ�ǰ��ϵ������ȡ��eV*s^2*nm^-2
q = 1.6021773349e-19;%���ӵ��


%ƫѹ��ѡȡ
ds = [0  -0.0125  -0.025  -0.0375  -0.05  -0.0625  -0.075  -0.0875  -0.1 -0.1125  -0.125 -0.1375 -0.15 -0.1625  -0.175 -0.1875  -0.2  -0.2125 -0.225 -0.2375 -0.25...
     -0.2625  -0.275  -0.2875  -0.3 -0.3125  -0.325  -0.3375  -0.35  -0.3625  -0.375  -0.3875  -0.4  -0.4125  -0.425  -0.4375 -0.45  -0.4625  -0.475  -0.4875  -0.5];
ds1 = linspace(0,0.5,41);
Vl = 0;
Vr = ds(1);

N = 81;
M = 64;

xmax = 45.2;
xmin = 0;
x = linspace(xmin,xmax,N);
x(50) = 27.685;
xx = linspace(xmin,xmax,161);
xx(99) = 27.685;
hx  =( xmax - xmin)/(N-1);
hy = 2*hx;
x_up = x(2:end);
x_up = x_up - hx/2;

kmax = pi/hy;
k  = linspace(-kmax,kmax,M+1);
hk = 2*kmax/M;
k = k-hk/2;
k(1) = [];
[X,K] = meshgrid ( x, k );



kk  = linspace(-2*kmax,2*kmax,M+1);
hkk = 4*kmax/M;
kk = kk-hkk/2;
kk(1) = [];












V1 = V(x,Vl,0);
V2 = V(x,Vl,-0.1);
V3 = V(x,Vl,-0.2);
V4 = V(x,Vl,-0.3);
V5 = V(x,Vl,-0.4);
V6 = V(x,Vl,-0.5);
figure
plot(x,V1,'.-')
hold on
plot(x,V2,'o-')
hold on
plot(x,V3,'*-')
hold on
plot(x,V4,'+-')
hold on
plot(x,V5,'p-')
hold on
plot(x,V6,'>-')
xlabel('nm')
ylabel('ev')
legend('ƫѹ=0','ƫѹ=-0.1','ƫѹ=-0.2','ƫѹ=-0.3','ƫѹ=-0.4','ƫѹ=-0.5')


 

function Vval = V(x,Vl,Vr)%�ƺ���
VV = 0.27;
V0val = VV.*(17.515<=x&x<=20.34)+VV.*(24.86<=x&x<=27.685)+0.*(x<17.515|x>27.685)+0.*(20.34<x&x<24.86);
Vdsval = Vl.*(x<17.515)+Vr.*(x>27.685)+((Vr-Vl)/10.17.*x+((27.685)*Vl-(17.515)*Vr)/10.17).*(17.515<=x&x<=27.685);
Vval = V0val+Vdsval;
end


function g_val = g(k)
beta =  38.6814933;
m0 =  5.69e-30;
m = 0.0665*m0;
hbar =  6.582122020e-16;
mu =  0.07969610918933088;
g_val = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
end


function f0_exact_val = f0_exact(x,k)
beta =  38.6814933;
m0 =  5.69e-30;
m = 0.0665*m0;
hbar =  6.582122020e-16;
mu =  0.07969610918933088;
if x <=0&&k>0
   f0_exact_val  = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
elseif x >=45.2&&k<0
   f0_exact_val  = m/(pi*hbar^2*beta).*log(1+exp(-beta*(hbar^2.*k.*k/(2*m)-mu)))*10^14;
else
    f0_exact_val = 0;
end
end


